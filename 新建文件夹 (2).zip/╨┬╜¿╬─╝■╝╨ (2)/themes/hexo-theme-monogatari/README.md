# hexo-theme-monogatari

hexo-theme-monogatari is the [theme](https://github.com/hexojs/hexo/wiki/Themes) for [Hexo](http://hexo.io/).

## Demo

* [PHP Explore (PHP 探索)](http://foreachsam.github.io/blog-lang-php/article/)

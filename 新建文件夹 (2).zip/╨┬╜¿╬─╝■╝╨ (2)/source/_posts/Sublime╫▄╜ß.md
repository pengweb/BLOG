---
title: Sublime总结
date: 2016-03-21 23:30:00
tags: [sublime]

---
只总结常用快捷键：

## Ctrl+Shift+P
   功能很强大，可以设置语法，也可以安装插件

## Ctrl+H
         替换
选中一个后

## Ctrl+D
         一个一个选中，之后一起操作   (Ctrl+K跳过)

## Alt+F3
         一下选中所有聚焦词，之后一起操作

## Ctrl+Alt+L
     先选中然后再按这个快捷键，就会在选区的所有后边加上操作符

## Ctrl+Shift+D
   和idea的Ctrl+D一样复制

## Ctrl+L
         选中整行

## Ctrl+Shift+M
   选中括号内元素

## Ctrl+M
   选中括号另外一边

## Ctrl+X
   删除整行

## Ctrl+W
   关闭当前标签页

## Ctrl+Shift+W
   关闭所有标签页

## Ctrl+PageDown
向左切换当前窗口的标签页

## Ctrl+PageUp
 向右切换当前窗口的标签页

## Ctrl+Shift+'
同时选中开始和闭合标签--要先选中一个 

## Ctrl+P
1、输入当前项目中的文件名，快速搜索文件
2、输入@和关键字，查找文件中函数名
3、输入：和数字，跳转到文件中该行代码
4、输入#和关键字，查找变量名

不常用：


## Ctrl+Alt+;

移除未闭合标签


## Ctrl+Shift+W

插入一个p标签